Name: Wang Jonghyuk
Student ID: 20220425

Time spent: 8~10 hours

